import Hello from "./Hello";

function App() {
  return (
    <div>
      <Hello name='최성욱' age='18'/>
    </div>
  );
}

export default App;
