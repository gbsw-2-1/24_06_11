const Hello = (props) => {
    return(
        <div>
            {props.name}
            {props.age}
        </div>
    )
}

export default Hello;